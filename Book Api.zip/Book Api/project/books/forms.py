# Form imports
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


# Flask forms (wtforms) allow you to easily create forms in format:
class CreateBook(FlaskForm):
    name = StringField('Title', validators=[DataRequired()])
    author = StringField('Author', validators=[DataRequired()])
    isbn = StringField ('ISBN', validators=[DataRequired()])  
    year_published = StringField('Publication Date', validators=[DataRequired()])
    submit = SubmitField('Create Book')
